import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:academy/components/button/main_button.dart';
import 'package:academy/components/footer/footer.dart';
import 'package:academy/provider/answer_state.dart';
import 'package:academy/provider/test_state.dart';
import 'package:academy/util/behavior.dart';
import 'package:academy/util/loading.dart';
import 'package:academy/util/refresh_manager.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:get/get.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:academy/components/dialog/showAlertDialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:pdfx/pdfx.dart';

import '../../../../firebase/firebase_test.dart';
import '../../../../util/colors.dart';
import '../../../../util/count_down.dart';
import '../../../../util/font/font.dart';
import '../../../login/login_main_screen.dart';
import '../../main_screen.dart';

class TestMainScreenTablet extends StatefulWidget {
  static final String id = '/test_main_screen_tablet';
  final String? teacher;
  final String? docId;
  final String? hasAudio;
  final FutureOr<Uint8List>? content;

  const TestMainScreenTablet(
      {Key? key, this.content, this.teacher, this.docId, this.hasAudio})
      : super(key: key);

  @override
  State<TestMainScreenTablet> createState() => _TestMainScreenTabletState();
}

class _TestMainScreenTabletState extends State<TestMainScreenTablet>
    with SingleTickerProviderStateMixin {
  bool isLoading = true;
  final as = Get.put(AnswerState());
  late PDFViewController controller;
  int pages = 0;
  int indexPage = 0;
  bool _isPlaying = false;
  String _hasA = '';
  String _docId = '';
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  ScrollController _scrollController = ScrollController();
  List<String> number = ['1', '2', '3', '4', '5'];
  List<String> _answer = [];
  AudioPlayer _player = AudioPlayer();
  late AnimationController _controller;
  TextEditingController _numberCon = TextEditingController();

  void addNumber() async {
    for (int i = 0; i < as.answerlength.length; i++) {
      _answer.add('');
      print('2');
    }
  }

  // late PdfControllerPinch pdfController;
  late PdfController _pdfController;

  @override
  void initState() {
    final ts = Get.put(TestState());

    // pdfController =
    //     PdfControllerPinch(document: PdfDocument.openData(widget.content));
    // _pdfController = PdfController(document: PdfDocument.openData(null));
    // String hey = '';
    // FutureOr<Uint8List>? godjob;
    // godjob = hey as FutureOr<Uint8List>?;

    if (RefreshManager.getCookie('test') != '') {
      print('1-------');
      _pdfController = PdfController(
        document: PdfDocument.openData(
            RefreshManager.getCookie('test') as FutureOr<Uint8List>),
      );
    } else {
      Future.delayed(Duration.zero, () async {
        final args =
            ModalRoute.of(context)!.settings.arguments as TestMainScreenTablet;
        await _player.setSourceUrl(
            'https://firebasestorage.googleapis.com/v0/b/academy-957f7.appspot.com/o/teacher%2Faudio%2F${args.teacher}%2F${args.docId}%2F${args.docId}?alt=media');
        _docId = '${args.docId}';
        _pdfController = PdfController(
          document: PdfDocument.openData(args.content!),
        );
        _hasA = args.hasAudio == 'yes' ? 'true' : 'false';
        addNumber();
        setState(() {
          isLoading = false;
        });
      });
    }

    _controller = AnimationController(
        vsync: this,
        duration: Duration(
            seconds: as.temp2.value != '' ? int.parse(as.temp2.value) : 0));
    _controller.addListener(() async {
      ts.answer.value = _answer;
      if (as.temp2.value != '') {
        if (1 == _controller.value) {
          await firebaseTestUpload(_docId, context);
        }
      }
    });
    (as.temp2.value == '' || as.temp2.value == '0')
        ? _controller.stop()
        : _controller.forward();

    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _player.dispose();
    _pdfController.dispose();
    _controller.stop();
    _controller.dispose();
    _numberCon.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ts = Get.put(TestState());
    final as = Get.put(AnswerState());

    //willpopscope add
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(130),
        child: AppBar(
          // centerTitle: true,
          toolbarHeight: 130,
          title: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _hasA == 'true'
                      ? FloatingActionButton.small(
                          backgroundColor: nowColor,
                          child: Icon(
                            _isPlaying ? Icons.pause : Icons.play_arrow,
                            color: Colors.white,
                          ),
                          onPressed: () async {
                            print('audio in ------');
                            // await _player.setSourceUrl(
                            //     'https://firebasestorage.googleapis.com/v0/b/academy-957f7.appspot.com/o/teacher%2Faudio%2FmiTeacher%2FdgcMnBOVScaHJ9aMc3Yi%2FdgcMnBOVScaHJ9aMc3Yi?alt=media');

                            if (!_isPlaying) {
                              _isPlaying = true;
                              _player.resume();
                            } else {
                              _isPlaying = false;
                              _player.pause();
                            }
                            setState(() {});
                          },
                        )
                      : Container(),
                  GestureDetector(
                    onTap: (){
                      showEditDialog(context, '몇 페이지로 이동하시겠습니까', () {
                        Get.back();
                        _pdfController.animateToPage(
                          int.parse('${_numberCon.text}'),
                          duration: Duration(milliseconds: 200),
                          curve: Curves.linear,
                        );
                      }, _numberCon);
                      },
                    child: PdfPageNumber(
                      controller: _pdfController,
                      builder: (_, loadingState, page, pagesCount) => Container(
                        alignment: Alignment.center,
                        child: Text(
                          '문제 $page/${pagesCount ?? 0}',
                          style: f16w400grey8,
                        ),
                      ),
                    ),
                  ),
                  Center(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: modelSheetClick,
                      child: Text(
                        '정답 입력',
                        style: kIsWeb && (Get.width * 0.2 <= 171)
                            ? f14w700primary
                            : f16w700primary,
                      ),
                    ),
                  )
                ],
              ),
              Center(
                child: Row(
                  children: [
                    Spacer(),
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Color(0xffDADADA),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(8))
                      ),
                      child: IconButton(
                        icon: const Icon(
                          Icons.navigate_before,
                          color: Colors.black,
                        ),
                        splashColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onPressed: () {
                          _pdfController.previousPage(
                            curve: Curves.ease,
                            duration: const Duration(milliseconds: 100),
                          );
                        },
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Center(
                      child: (as.temp2.value == '' || as.temp2.value == '0')
                          ? Text(
                              '시간제한 없음',
                              style: f42w700,
                            )
                          : Countdown(
                              animation: StepTween(
                                begin: as.temp2.value != ''
                                    ? int.parse(as.temp2.value)
                                    : 0,
                                end: 0,
                              ).animate(_controller),
                            ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                          border: Border.all(
                            color: Color(0xffDADADA),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(8))
                      ),
                      child: IconButton(
                        icon: const Icon(
                          Icons.navigate_next,
                          color: Colors.black,
                        ),
                        splashColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onPressed: () {
                          _pdfController.nextPage(
                            curve: Curves.ease,
                            duration: const Duration(milliseconds: 100),
                          );
                        },
                      ),
                    ),
                    Spacer()
                  ],
                ),
              ),
            ],
          ),
          elevation: 0,
          automaticallyImplyLeading: false,
          backgroundColor: Colors.white,
        ),
      ),
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: ListView(
          shrinkWrap: true,
          children :[
            Container(
              width: Get.width,
              height: Get.height,
              child: PdfView(
                builders: PdfViewBuilders<DefaultBuilderOptions>(
                  options: const DefaultBuilderOptions(),
                  documentLoaderBuilder: (_) =>
                  const Center(child: CircularProgressIndicator()),
                  pageLoaderBuilder: (_) =>
                  const Center(child: CircularProgressIndicator()),
                  pageBuilder: _pageBuilder,
                ),
                controller: _pdfController,
              ),
            ),

            Footer(),
          ]
        ),
      ),
    );
  }

  PhotoViewGalleryPageOptions _pageBuilder(
    BuildContext context,
    Future<PdfPageImage> pageImage,
    int index,
    PdfDocument document,
  ) {
    return PhotoViewGalleryPageOptions(
      imageProvider: PdfPageImageProvider(
        pageImage,
        index,
        document.id,
      ),
      minScale: PhotoViewComputedScale.contained * 1,
      maxScale: PhotoViewComputedScale.contained * 2,
      initialScale: PhotoViewComputedScale.contained * 1.0,
      heroAttributes: PhotoViewHeroAttributes(tag: '${document.id}-$index'),
    );
  }

  void modelSheetClick() {
    final ts = Get.put(TestState());
    showModalBottomSheet(
        backgroundColor: Colors.white24,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        )),
        context: context,
        isScrollControlled: true,
        builder: (builder) {
          return StatefulBuilder(builder: (context, setState) {
            return ScrollConfiguration(
              behavior: MyBehavior(),
              child: DraggableScrollableSheet(
                  initialChildSize: 0.5,
                  maxChildSize: 0.5,
                  minChildSize: 0.3,
                  expand: false,
                  builder: (BuildContext context,
                      ScrollController scrollController) {
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(0, 25, 25, 0),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              TextButton(
                                onPressed: () {
                                  showComponentDialog(context, '제출하시겠습니까?',
                                      () async {
                                    // answerListAdd('SIg3OP2qqovlBZROIaRr');
                                    ts.answer.value = _answer;
                                    Get.back();
                                    await firebaseTestUpload(_docId, context);
                                  });
                                },
                                child: Text(
                                  '제출',
                                  style: f18w700primary,
                                ),
                              ),
                            ],
                            mainAxisAlignment: MainAxisAlignment.end,
                          ),
                          Expanded(
                            child: ListView.builder(
                              physics: const ClampingScrollPhysics(),
                              shrinkWrap: true,
                              itemCount: as.answerlength.length,
                              controller: scrollController,
                              itemBuilder: (_, index) {
                                return Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text('${index + 1}번 문제', style: f18w500),
                                      isLoading
                                          ? LoadingBodyScreen()
                                          : Container(
                                              height: 60,
                                              child: ListView(
                                                scrollDirection:
                                                    Axis.horizontal,
                                                children: number.map((number) {
                                                  return Row(
                                                    children: [
                                                      TextButton(
                                                          onPressed: () {
                                                            _answer[index] =
                                                                number;
                                                            setState(() {});
                                                          },
                                                          style: TextButton.styleFrom(
                                                              minimumSize:
                                                                  Size(52, 52),
                                                              foregroundColor: Colors
                                                                  .transparent,
                                                              backgroundColor:
                                                                  _answer[index] ==
                                                                          number
                                                                      ? nowColor
                                                                      : Colors
                                                                          .white,
                                                              padding:
                                                                  EdgeInsets.only(
                                                                      right: 12,
                                                                      left: 12),
                                                              tapTargetSize:
                                                                  MaterialTapTargetSize
                                                                      .shrinkWrap,
                                                              shape: RoundedRectangleBorder(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          20),
                                                                  side: BorderSide(
                                                                      width: 1,
                                                                      color: Colors.grey))),
                                                          child: Text(
                                                            '$number',
                                                            style: _answer[
                                                                        index] ==
                                                                    number
                                                                ? f16Whitew700
                                                                : f16w700,
                                                          )),
                                                      SizedBox(
                                                        width: 10,
                                                      )
                                                    ],
                                                  );
                                                }).toList(),
                                              )),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
            );
          });
        });
  }
}
