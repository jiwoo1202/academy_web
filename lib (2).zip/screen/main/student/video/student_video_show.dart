import 'dart:typed_data';

import 'package:academy/provider/user_state.dart';
import 'package:academy/util/loading.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:video_player/video_player.dart';
import 'dart:html' as html;
import 'package:http/http.dart' as http;

import '../../../../components/dialog/showAlertDialog.dart';
import '../../../../util/font/font.dart';
class StudentVideoShow extends StatefulWidget {
  static final String id = '/student_video_show';
  final String? videoName;
  final String? docId;
  final String? teacherDocId;
  final String? title;
  const StudentVideoShow({Key? key, this.videoName, this.docId, this.teacherDocId, this.title}) : super(key: key);

  @override
  State<StudentVideoShow> createState() => _StudentVideoShowState();
}

class _StudentVideoShowState extends State<StudentVideoShow> {
   VideoPlayerController? videoPlayerController;
   ChewieController? _chewieController;
  Duration _currentPosition = Duration.zero;
  int? bufferDelay;
  bool _isPlaying = false;
  late Uint8List uploadfile;
  @override
  void initState() {
    final us = Get.put(UserState());
    Future.delayed(Duration.zero,()async{
      final args = ModalRoute.of(context)!.settings.arguments as StudentVideoShow;
      final videoBytes = await http.readBytes(Uri.parse('https://firebasestorage.googleapis.com/v0/b/academy-957f7.appspot.com/o/video%2F${args.teacherDocId}%2F${args.videoName}.mp4?alt=media'));
      uploadfile = await http.readBytes(Uri.parse('https://firebasestorage.googleapis.com/v0/b/academy-957f7.appspot.com/o/video%2F${args.teacherDocId}%2F${args.videoName}.mp4?alt=media'));
      _initializeVideoPlayer(videoBytes);
    });
    super.initState();
  }
   void dispose() {
     videoPlayerController?.dispose();
     _chewieController?.dispose();
     super.dispose();
   }
  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments as StudentVideoShow;
    return WillPopScope(
      onWillPop: (){
        return onTerminated(context);
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: Color(0xff270BD3),
          title: Text(
            '${args.title}',
            style: f24w500,
          ),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.only(right: 320, left: 320,top: 100),
          child: Column(
            children: [
              Container(
                width: Get.width * 0.8,
                height: Get.height * 0.5,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Color(0xff3A8EFF))
                ),
                  child: _chewieController!=null?Chewie(controller: _chewieController!):LoadingBodyScreen()
              ),
            ],
          ),
        )
      ),
    );
  }
  Future<void> _initializeVideoPlayer(Uint8List videoBytes) async {

    final blob = html.Blob([videoBytes]);
    final videoUrl = html.Url.createObjectUrlFromBlob(blob);
    videoPlayerController = VideoPlayerController.network(videoUrl)
      ..initialize().then((value) {
        videoPlayerController!.seekTo(_currentPosition);
        setState(() {});
      });

    _chewieController = ChewieController(
      videoPlayerController: videoPlayerController!,
      // autoPlay: true,
      aspectRatio: 16/9,
      deviceOrientationsAfterFullScreen:[DeviceOrientation.portraitUp] ,
      looping: false,
      progressIndicatorDelay:
      bufferDelay != null ? Duration(milliseconds: bufferDelay!) : null,
      hideControlsTimer: _isPlaying ? Duration(seconds: 1) : Duration(days: 1),
    )..addListener(_reInitListener);

    if (_isPlaying) {
      print('1111');
      _chewieController!.play();
    }
    RawKeyboard.instance.addListener((event) {
      if (event is RawKeyDownEvent) {
        if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
          // 화살표 왼쪽 키를 눌렀을 때
          final currentPosition = _chewieController!.videoPlayerController.value.position;
          final newPosition = currentPosition - Duration(seconds: 10);
          _chewieController!.videoPlayerController.seekTo(newPosition);
        } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
          // 화살표 오른쪽 키를 눌렀을 때
          final currentPosition = _chewieController!.videoPlayerController.value.position;
          final newPosition = currentPosition + Duration(seconds: 10);
          _chewieController!.videoPlayerController.seekTo(newPosition);
        }
        else if (event.logicalKey == LogicalKeyboardKey.escape) {
          // ESC 키를 눌렀을 때
          if (_chewieController!.isFullScreen) {
            _chewieController!.exitFullScreen();
          }
        }
      }
    });
    setState(() {});
  }
  void _reInitControllers() {
    _chewieController?.removeListener(_reInitListener);
    _currentPosition = videoPlayerController!.value.position;
    _isPlaying = _chewieController!.isPlaying;
    _initializeVideoPlayer(uploadfile);
  }
  void _reInitListener() {
    if (!_chewieController!.isFullScreen) {
      _reInitControllers();
    }
  }
   Future<bool> onTerminated(BuildContext context) async {
     return showComponentDialog(context, '강의를 종료하겠습니까?', () {
       Get.back();
       Get.back();
     });
   }
}
