import 'package:academy/provider/sat_state.dart';
import 'package:academy/provider/user_state.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../util/refresh_manager.dart';
///satAnswer Collection
/// 학생이 처음 만들때
Future<void> firebaseSatCreate(String answerDocId) async {
  try {
    final us = Get.put(UserState());
    final st = Get.put(SatState());
    String docId = '';
    final CollectionReference ref = FirebaseFirestore.instance.collection('satAnswer');
    await ref.add({
      'answer':[],
      'answerDocId':'${answerDocId}',
      'createDate':'${DateTime.now()}',
      'id':'${us.userList[0].id}',
      'nickName':'${us.userList[0].nickName}',
      'score':0,
      'status':'',
      'time':'',
      'minute':'',
      'second':'',
      'teacher':'선생님 이름',
      'testTitle':'테스트 이름'
    }).then((doc) async {
      DocumentReference userDocRef = FirebaseFirestore.instance.collection('satAnswer').doc(doc.id);
      await userDocRef.update({'docId': '${doc.id}'});
      docId = '${doc.id}';
    });
    RefreshManager.addToCookie('satUpdateDocId', '${docId}'); /// 업데이트할 docID저장
    st.satUpdateDocId.value = docId;

    // CollectionReference ref2 = FirebaseFirestore.instance.collection('satAnswer');
    // QuerySnapshot snapshot2 = await ref2.where('docId', isEqualTo: '${docId}').get();
    // final allData = snapshot2.docs.map((doc) => doc.data()).toList();
    // List a = allData;
    // RefreshManager.addToCookie('studentList', '${a}'); /// 업데이트할 docId가져옴

  } catch (e) {
    print(e);
  }
}
/// 학생이 문제 입력할때마다 업데이트
Future<void> firebaseSatAnswerUpdate(List answer) async {
  final st = Get.put(SatState());
  print('업데이트 하는 닥 ${st.satUpdateDocId}');
  DocumentReference doRef = FirebaseFirestore.instance.collection('satAnswer').doc('${st.satUpdateDocId}');
  doRef.update({
    'answer': answer,
  });
}
/// 학생이 문제 입력할때마다 업데이트
Future<void> firebaseSatTimeUpdate(int minute,int second) async {
  final st = Get.put(SatState());
  DocumentReference doRef = FirebaseFirestore.instance.collection('satAnswer').doc('${st.satUpdateDocId}');

  doRef.update({
    'minute':'${minute}',
    'second':'${second}'
  });
}
  /// sat Collection
  /// 선생님 시험정보 가져오기
  Future<void> firebaseSatGet() async {
    final st = Get.put(SatState());

    CollectionReference ref = FirebaseFirestore.instance.collection('sat');
    QuerySnapshot snapshot = await ref.where('docId', isEqualTo: '${st.satTeacherDocId.value}').get();

    final allData = snapshot.docs.map((doc) => doc.data()).toList();
    st.individualSatGet.value = allData;
  }
