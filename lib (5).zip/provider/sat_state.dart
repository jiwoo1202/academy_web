import 'package:academy/model/user.dart';
import 'package:get/get.dart';

class SatState extends GetxController{

  final individualSatGet = [].obs; /// 선생님 시험 정보 담는 변수
  final totalAnswer = [].obs;
  final controllerList = [].obs;

  final satUpdateDocId = ''.obs; /// 학생이 문제 업데이트

  ///
  final satTeacherDocId = ''.obs;
  final satmyPage = ''.obs;
  final satpart  = ''.obs;
}