import 'package:get/get.dart';

class CommunityState extends GetxController{
  final comTitle = ''.obs;
  final comTitle2 = ''.obs;
  final comBlock = [].obs;
  final communityList = [].obs; //detail 데이터용


  final communDocId = ''.obs;
  final storyId = ''.obs;
}